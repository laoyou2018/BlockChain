import UIKit
import CommonCrypto
//let queue = DispatchQueue.init(label: "main")
//
//queue.sync {
//    print(1)
//}
//
//queue.async {
//    Thread.sleep(forTimeInterval: 5.0)
//    print(2)
//}
//
//queue.sync {
//    print(3)
//}

/*
    hash = SHA-256 (最后一个区块的hash + 新区块的基本信息 + 交易记录信息 + 随机数)
 */
class Block: Codable {
    /// 在区块链中第几位账本
    var index: Int = 0
    /// 当前账本的上一个账本的哈希值
    var previousHash: String = ""
    /// 该账本的哈希值
    var hash: String!
    /// 递增数字
    var noice: Int
    
    private (set) var transactions: [Transaction] = [Transaction]()
//    key - 计算属性, 提供给产生哈希值的函数
    var key: String {
        get {
            let transactionData = try! JSONEncoder().encode(self.transactions)
            let transactionJSONString = String(data: transactionData, encoding: .utf8)
            return String(self.index) + String(previousHash) + String(self.noice) + transactionJSONString!
        }
    }
    
    func addTransaction(transaction: Transaction) {
        self.transactions.append(transaction)
    }
    
    init() {
        self.noice = 0
    }
    
}

/*
    区块链中的交易内容：
    Codable 数据属于json格式  codable表示可以解析
    from 交易的甲方
    to 交易的乙方
    amount 交易的数值内容
 */

class Transaction: Codable {
    var from: String!
    var to: String!
    var amount: Double
    
    init?(from: String?,to: String?, amount : Double) {
        guard from != nil && to != nil else {
            return nil
        }
        self.from = from
        self.to = to
        self.amount = amount
    }
}

/*
 
    实现区块类
    区块链(BlockChain)需要一个区块来初始化自己，这个区块也叫做创世区块(Genesis Block)，然后实现后面的
 */

class BlockChain: Codable {
    private (set) var blocks: [Block] = [Block]()
    init(genesisBlock: Block) {
        addBlock(genesisBlock) // 创建爱你第一本账本
    }
    
    func addBlock(_ block: Block) -> Void {
        if self.blocks.isEmpty {
            block.previousHash = "000000000000" /// 第一个账本的哈希值
            block.hash = generateHash(for: block) // 后来的账本生成hash
        }
        self.blocks.append(block)
    }
    /// 创建后来账本的hash
    func generateHash(for block:Block) -> String {
        var hash = block.key.sha1()
        
        //
        while !hash.hasPrefix("00") {
            block.noice += 1
            hash = block.key.sha1()
        }
        return hash
    }
    func getNextBlock(transactions : [Transaction]) -> Block {
        
        let block = Block()
        
        transactions.forEach { (transaction) in
            
            block.addTransaction(transaction: transaction)
        }
        
        let previousBlock = getPreviousBlock()
        block.index = self.blocks.count
        block.previousHash = previousBlock.hash
        block.hash = generateHash(for: block)
        return block
    }
    
    private func getPreviousBlock() -> Block {
        return self.blocks[self.blocks.count - 1]
    }
    
}

// sha1 算法, 将 NSString 转换成 sha1
extension String {
    
    func sha1() -> String {
        
        let data = self.data(using: String.Encoding.utf8)!
        
        var digest = [UInt8](repeating: 0, count:Int(CC_SHA1_DIGEST_LENGTH))
        
        let newData = NSData.init(data: data)
        
        CC_SHA1(newData.bytes, CC_LONG(data.count), &digest)
        
        let output = NSMutableString(capacity: Int(CC_SHA1_DIGEST_LENGTH))
        
        for byte in digest {
            
            output.appendFormat("%02x", byte)
            
        }
        
        return output as String
       
        
//        let task = Process()
//        task.launchPath = "/usr/bin/shasum"
//        task.arguments = []
//
//        let inputPipe = Pipe()
//
//        inputPipe.fileHandleForWriting.write(self.data(using: .utf8, allowLossyConversion: true)!)
//
//        inputPipe.fileHandleForWriting.closeFile()
//
//        let outputPipe = Pipe()
//
//        task.standardOutput = outputPipe
//        task.standardInput = inputPipe
//        task.launch()
//
//        let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
//        let hash = String(data: data, encoding: .utf8)
//
//        return (hash?.replacingOccurrences(of: "  -\n", with: ""))!
    }
}




/**
 *  区块链的优缺点
 *  优点:
 1. 去中心化
 2. 不可修改
 *  缺点:
 1. 资源的消耗特别大
 2. 网路延迟
 *
 *  金融, 教学资源, 基因数据, 游戏
 */


let genesisBlock = Block()

var transaction = Transaction(from: "dx", to: "xzp", amount: 10)
genesisBlock.addTransaction(transaction: transaction!)

let blockChain = BlockChain(genesisBlock: genesisBlock)


print("--------------------------------")

transaction = Transaction(from: "swift", to: "objc", amount: 20)

let block = blockChain.getNextBlock(transactions: [transaction!])
blockChain.addBlock(block)
print(blockChain.blocks.count)
